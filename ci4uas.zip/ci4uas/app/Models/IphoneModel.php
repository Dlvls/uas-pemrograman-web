<?php

namespace App\Models;

use CodeIgniter\Model;

class IphoneModel extends Model
{
    protected $table = 'tb_iphone';

    public function getIphone($slug = false)
    {
        if ($slug == false) {
            return $this->findAll();
        }

        return $this->where(['slug' => $slug])->first();
    }

    public function totProduct()
    {        
        return $this->db->table('tb_product')
                        ->countAll();
    } 

    public function totProductCat()
    {        
        $sql = "SELECT COUNT(DISTINCT(product_category)) AS total FROM tb_product";
        return $this->db->query($sql)->getResult();
    } 
    
    public function getProduct()
    {
        return $this->db->table('tb_product')
                        ->select('*')
                        ->get()->getResultArray();  
    }
      
    public function insertProduct($data)
    {
        return $this->db->table('tb_product')
                        ->insert($data);
    }
    
    public function updateProduct($data, $id)
    {
        return $this->db->table('tb_product')
                        ->update($data, array('product_id' => $id));
    }

    public function deleteProduct($id)
    {
        return $this->db->table('tb_product')
                        ->delete(array('product_id' => $id));
    }
}
