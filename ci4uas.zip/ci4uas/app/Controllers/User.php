<?php

namespace App\Controllers;
use App\Models\IphoneModel;

class User extends BaseController
{

    protected $iphoneModel;
    public function __construct()
    {
        $this->iphoneModel = new IphoneModel();
    }

    public function index()
    {
        $Iphone = $this->iphoneModel->findAll();
        $data = [
            'title' => 'TOWN IPHONE',
            'Iphone' => $this->iphoneModel->getIphone()
        ];
        return view('user/home', $data);
    }

    public function detail($slug)
    {
        $data = [
            'title' => 'Detail',
            'iphone' => $this->iphoneModel->getIphone($slug)
        ];
        return view('user/detail', $data);
    }
    
    public function beli($slug)
    {
        $data = [
            'title' => 'Beli',
            'iphone' => $this->iphoneModel->getIphone($slug)
        ];
        return view('user/beli', $data);
    }
}
