<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>TOWN IPHONE</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="<?= base_url(); ?>/img/favicon.png" rel="icon">
  <script src="https://kit.fontawesome.com/0d363a6320.js" crossorigin="anonymous"></script>
  <link href="<?= base_url(); ?>/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?= base_url(); ?>/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="<?= base_url(); ?>/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="<?= base_url(); ?>/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?= base_url(); ?>/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="<?= base_url(); ?>/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="<?= base_url(); ?>/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="<?= base_url(); ?>/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="<?= base_url(); ?>/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="<?= base_url('<?= base_url(); ?>/css/style-detail.css'); ?>" rel="stylesheet">
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
  <link href="<?= base_url(); ?>/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Medilab - v4.7.1
  * Template URL: https://bootstrapmade.com/medilab-free-medical-bootstrap-theme/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">

      <h1 class="logo me-auto"><a href="index.html">TOWN IPHONE </a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo me-auto"><img src="<?= base_url(); ?>/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <?php if (in_groups('admin')) : ?>
          <li><a class="nav-link scrollto" href="<?= site_url('admin/index'); ?>">Admin Page</a></li>
          <?php endif; ?>
          <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
          <li><a class="nav-link scrollto" href="#about">About</a></li>
          <li><a class="nav-link scrollto" href="#Series">Series</a></li>
          <li><a class="nav-link scrollto" href="#gallery">Gallery</a></li>
          <li><a class="nav-link scrollto" href="#contact">Contact</a></li>


        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->
      
      <?php if (in_groups('admin')) : ?>
      <a href="<?= base_url('logout'); ?>" class="appointment-btn scrollto"><span class="d-none d-md-inline">Logout</span></a>
      <?php endif; ?>
      
      <?php if (in_groups('user')) : ?>
        <a href="<?= base_url('logout'); ?>" class="appointment-btn scrollto"><span class="d-none d-md-inline">Logout</span></a>
      <?php endif; ?>

        <!-- <a href="" class="appointment-btn scrollto"><span class="d-none d-md-inline">Login</span></a> -->

    </div>
  </header><!-- End Header -->

<!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">
    <div class="container">
      <h1>SALE 7.7 </h1>
      <h2>Bergaransi 1tahun resmi ibox intern </h2>
      <a href="#about" class="btn-get-started scrollto">Get Started</a>
    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= Why Us Section ======= -->
    <section id="why-us" class="why-us">
      <div class="container">

        <div class="row">
          <div class="col-lg-4 d-flex align-items-stretch">
            <div class="content">
              <h3>Why Choose TOWN IPHONE</h3>
              <p>
                kami menyediakan type iphone terbaru bergaransi resmi ibox.
                dapatkan harga menarik setiap bulannya
              </p>
              <div class="text-center">
                <a href="#" class="more-btn">Learn More <i class="bx bx-chevron-right"></i></a>
              </div>
            </div>
          </div>
          <div class="col-lg-8 d-flex align-items-stretch">
            <div class="icon-boxes d-flex flex-column justify-content-center">
              <div class="row">
                <div class="col-xl-4 d-flex align-items-stretch">
                  <div class="icon-box mt-4 mt-xl-0">
                    <i class="bx bx-receipt"></i>
                    <h4>Cicilan Mulai Dari 0%</h4>
                  </div>
                </div>
                <div class="col-xl-4 d-flex align-items-stretch">
                  <div class="icon-box mt-4 mt-xl-0">
                    <i class="bx bx-cube-alt"></i>
                    <h4>Dijamin Ori</h4>
                  </div>
                </div>
                <div class="col-xl-4 d-flex align-items-stretch">
                  <div class="icon-box mt-4 mt-xl-0">
                    <i class="bx bx-images"></i>
                    <h4>Harga Terjangkau</h4>
                  </div>
                </div>
              </div>
            </div><!-- End .content-->
          </div>
        </div>

      </div>
    </section><!-- End Why Us Section -->

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container-fluid">

        <div class="row">
          <div class="col-xl-5 col-lg-6 video-box d-flex justify-content-center align-items-stretch position-relative">
            <a href="https://youtu.be/zJFwOC_Bv4Y" class="glightbox play-btn mb-4"></a>
          </div>

          <div class="col-xl-7 col-lg-6 icon-boxes d-flex flex-column align-items-stretch justify-content-center py-5 px-lg-5">
            <h3>Iphone 14 Series</h3>

            <div class="icon-box">
              <div class="icon"><i class="fa-solid fa-display"></i></i></div>
              <!-- <div class="icon"><i class="bx bx-fingerprint"></i></div> -->
              <h4 class="title"><a href="">Display</a></h4>
              <p class="description">Dilengkapi dengan layar ProMotion</p>
            </div>

            <div class="icon-box">
              <div class="icon"><i class="fa-solid fa-microchip"></i></i></i></div>
              <h4 class="title"><a href="">Chipset</a></h4>
              <p class="description">Iphone 14 reguler dan max menggunakan chipset Apple A15 Bionic, dan A16 Bionic untuk 14 versi pro dan promax akan menggunakan chipset A16 atau A16 pro Bionic juga akan menyertakan lensa zoom periskop dengan zoom optic yang lebih besar.
              </p>
            </div>

            <div class="icon-box">
              <div class="icon"><i class="fa-solid fa-camera"></i></div>
              <h4 class="title"><a href="">Camera</a></h4>
              <p class="description">Iphone 14 pro dan 14 pro max menggunakan kamera utama dengan sensor 48 MP mampu memrekam video hingga resolusi 8K.</p>
            </div>

          </div>
        </div>

      </div>
    </section><!-- End About Section -->

    <!-- ======= Counts Section ======= -->
    <section id="counts" class="counts">
      <div class="container">

        <div class="row">

          <div class="col-lg-3 col-md-6">
            <div class="count-box">
              <i class="fa-solid fa-battery-empty"></i></i>
              <span data-purecounter-start="0" data-purecounter-end="4650" data-purecounter-duration="1" class="purecounter"></span>
              <p>Battery</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-5 mt-md-0">
            <div class="count-box">
              <i class="fa-solid fa-memory"></i></i>
              <span data-purecounter-start="0" data-purecounter-end="6" data-purecounter-duration="1" class="purecounter"></span>
              <p>RAM</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-5 mt-lg-0">
            <div class="count-box">
              <i class="fa-solid fa-memory"></i>
              <span data-purecounter-start="0" data-purecounter-end="256" data-purecounter-duration="1" class="purecounter"></span>
              <p>ROM</p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 mt-5 mt-lg-0">
            <div class="count-box">
              <i class="fa-solid fa-mobile-screen"></i></i>
              <span data-purecounter-start="0" data-purecounter-end="120" data-purecounter-duration="1" class="purecounter"></span>
              <p>Hz</p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Counts Section -->

    <!-- ======= Services Section ======= -->
    <section id="Series" class="Series">
      <div class="container">

        <div class="section-title">
          <h2>Series</h2>
        </div>
        <div class="row">
          <?php foreach ($Iphone as $k) : ?>
            <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
              <div class="icon-box">
                <div class="icon">
                <i class="fa-brands fa-apple"></i>
                </div>
                <h4><a href="user/detail/<?= $k['slug'] ?>"><?= $k['nama'] ?></a></h4>
                <p>IDR <?= $k['harga'] ?></p>
              </div>
            </div>
          <?php endforeach; ?>

        </div>

      </div>
    </section><!-- End Services Section -->

    <!-- ======= Frequently Asked Questions Section ======= -->
    <section id="faq" class="faq section-bg">
      <div class="container">

        <div class="section-title">
          <h2>Frequently Asked Questions</h2>
          <p>.</p>
        </div>

        <div class="faq-list">
          <ul>
            <li data-aos="fade-up">
              <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" class="collapse" data-bs-target="#faq-list-1"> does my iphone have 3D touch?? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-1" class="collapse show" data-bs-parent=".faq-list">
                <p>
                apple has moved on from 3D touch, with newer devices using haptic touch instead. both peatures have a similar purpose , providing access to week actions, short card menus.and content previews.

To use 3D Touch, long press (or deep press) items on the iPhone display
                </p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="100">
              <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" data-bs-target="#faq-list-2" class="collapsed">What is the meaning of 5G status icons on iPhone?? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-2" class="collapse" data-bs-parent=".faq-list">
                <p>
                Currently the entire iPhone lineup including the iPhone SE supports 5G wireless connectivity. 5G provides lower latency and faster transfer speeds over 4G or LTE networks. There are several different bands / frequencies which may appear via icons in the iOS status bar when in use:

5G - standard 5G network (also known as Verizon "5G Nationwide")
5G+ - mmWave 5G (fastest high frequency connection)
5G UW - mmWave 5G (Verizon “5G Ultra Wideband”)
5G UC - higher frequency 5G with some mmWave (T-Mobile “5G Ultra Capacity”)
                </p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="200">
              <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" data-bs-target="#faq-list-3" class="collapsed">How do I lock rotation in iOS? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-3" class="collapse" data-bs-parent=".faq-list">
                <p>
                It can be a bothersome when trying to use your iPhone in portrait mode (vertical) and it keeps accidentally spinning to landscape mode (horizontal). Whatever the reason you want to keep your iPhone stable, iOS provides an easy way to lock your device to stop it from rotating. Unfortunately, there is no way to lock your device in landscape mode in iOS.

iPhone rotation locking is located in the iOS Control Center. You can enable rotation lock and prevent the screen from automatically changing orientation when the iPhone is turned.
                </p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="300">
              <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" data-bs-target="#faq-list-4" class="collapsed">Why won't my earbuds / headphones connect to my iOS device? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-4" class="collapse" data-bs-parent=".faq-list">
                <p>
                Wireless earbuds or headphones may free you from the tangle of wires, but they offer another annoying problem. Sometimes third-party Bluetooth devices have trouble connecting to your iOS device after you remove or shut them down. Here's a few possible solutions to connect your wireless earbuds or headphones to your iPhone.
                </p>
              </div>
            </li>

            <li data-aos="fade-up" data-aos-delay="400">
              <i class="bx bx-help-circle icon-help"></i> <a data-bs-toggle="collapse" data-bs-target="#faq-list-5" class="collapsed">How do I transfer my Apple Pay Cash balance to my bank account? <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
              <div id="faq-list-5" class="collapse" data-bs-parent=".faq-list">
                <p>
                Money sent to your iPhone or iPad through Apple Pay Cash is added to your Wallet balance (you can learn how to check your balance here). Money posted to your Apple Pay Cash account can be used to make purchases at retail locations where Apple Pay is accepted, within apps and on the web. Money you send to others through the Messages app using Apple Pay Cash will be automatically deducted from your balance before being deducted from your connected debit/credit card.
                </p>
              </div>
            </li>

          </ul>
        </div>

      </div>
    </section><!-- End Frequently Asked Questions Section -->

    <!-- ======= Testimonials Section ======= -->
    <section id="testimonials" class="testimonials">
      <div class="container">

        <div class="testimonials-slider swiper" data-aos="fade-up" data-aos-delay="100">
          <div class="swiper-wrapper">

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <img src="<?= base_url(); ?>/img/testimonials/t3.jpeg" class="testimonial-img" alt="">
                  <h3>Fika nuraeni</h3>
                  <h4>Ceo &amp; Founder</h4>
                  <p>
                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                    it's a great recomendation to buy here
                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <img src="<?= base_url(); ?>/img/testimonials/t1.jpeg" class="testimonial-img" alt="">
                  <h3>marsha amalia</h3>
                  <h4>Designer</h4>
                  <p>
                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  i like to buy it here because of fast delivery
                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <img src="<?= base_url(); ?>/img/testimonials/t2.jpeg" class="testimonial-img" alt="">
                  <h3>Rifan afiansyah</h3>
                  <h4>Store Owner</h4>
                  <p>
                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                 it's cheap here and safe
                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <img src="<?= base_url(); ?>/img/testimonials/t4.jpeg" class="testimonial-img" alt="">
                  <h3>dandi fadilah</h3>
                  <h4>Freelancer</h4>
                  <p>
                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  i've already bought more than two here
                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <img src="<?= base_url(); ?>/img/testimonials/t5.jpeg" class="testimonial-img" alt="">
                  <h3>delvia lanasemba</h3>
                  <h4>Entrepreneur</h4>
                  <p>
                    <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                   just here to sell original phone and many sale in town phone i like it.
                    <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                  </p>
                </div>
              </div>
            </div><!-- End testimonial item -->

          </div>
          <div class="swiper-pagination"></div>
        </div>

      </div>
    </section><!-- End Testimonials Section -->

    <!-- ======= Gallery Section ======= -->
    <section id="gallery" class="gallery">
      <div class="container">

        <div class="section-title">
          <h2>Gallery</h2>
          <p>Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea. Quia fugiat sit in iste officiis commodi quidem hic quas.</p>
        </div>
      </div>

      <div class="container-fluid">
        <div class="row g-0">

        <?php foreach ($Iphone as $k) : ?>
          <div class="col-lg-3 col-md-4">
            <div class="gallery-item">
              <a href="<?= base_url(); ?>/img/gallery/ip1.jpeg" class="galelry-lightbox">
                <img src="<?= base_url(); ?>/img/gallery/<?= $k['img'] ?>" alt="" class="img-fluid">
              </a>
            </div>
          </div>
          <?php endforeach; ?>

        </div>

      </div>
    </section><!-- End Gallery Section -->

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container">

        <div class="section-title">
          <h2>Contact</h2>
          <p>Magnam dolores commodi suscipit. Necessitatibus eius consequatur ex aliquid fuga eum quidem. Sit sint consectetur velit. Quisquam quos quisquam cupiditate. Et nemo qui impedit suscipit alias ea. Quia fugiat sit in iste officiis commodi quidem hic quas.</p>
        </div>
      </div>

      <div>
        <iframe style="border:0; width: 100%; height: 350px;" src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d12097.433213460943!2d-74.0062269!3d40.7101282!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xb89d1fe6bc499443!2sDowntown+Conference+Center!5e0!3m2!1smk!2sbg!4v1539943755621" frameborder="0" allowfullscreen></iframe>
      </div>

      <div class="container">
        <div class="row mt-5">

          <div class="col-lg-4">
            <div class="info">
              <div class="address">
                <i class="bi bi-geo-alt"></i>
                <h4>Location:</h4>
                <p>A108 Adam Street, New York, NY 535022</p>
              </div>

              <div class="email">
                <i class="bi bi-envelope"></i>
                <h4>Email:</h4>
                <p>info@example.com</p>
              </div>

              <div class="phone">
                <i class="bi bi-phone"></i>
                <h4>Call:</h4>
                <p>+1 5589 55488 55s</p>
              </div>

            </div>

          </div>

          <div class="col-lg-8 mt-5 mt-lg-0">

            <form action="forms/contact.php" method="post" role="form" class="php-email-form">
              <div class="row">
                <div class="col-md-6 form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required>
                </div>
                <div class="col-md-6 form-group mt-3 mt-md-0">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required>
                </div>
              </div>
              <div class="form-group mt-3">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" required>
              </div>
              <div class="form-group mt-3">
                <textarea class="form-control" name="message" rows="5" placeholder="Message" required></textarea>
              </div>
              <div class="my-3">
                <div class="loading">Loading</div>
                <div class="error-message"></div>
                <div class="sent-message">Your message has been sent. Thank you!</div>
              </div>
              <div class="text-center"><button type="submit">Send Message</button></div>
            </form>

          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

<!-- ======= Footer ======= -->
<footer id="footer">

<div class="footer-top">
  <div class="container">
    <div class="row">

      <div class="col-lg-3 col-md-6 footer-contact">
        <h3>TOWN IPHONE</h3>
        <p>
          A108 Adam Street <br>
          New York, NY 535022<br>
          United States <br><br>
          <strong>Phone:</strong> +1 5589 55488 55<br>
          <strong>Email:</strong> info@example.com<br>
        </p>
      </div>

      <div class="col-lg-2 col-md-6 footer-links">
        <h4>Useful Links</h4>
        <ul>
          <li><i class="bx bx-chevron-right"></i> <a href="home">Home</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="about">About us</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="series">Series</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="gallery">Gallery</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="contact">Contact</a></li>
        </ul>
      </div>

      <div class="col-lg-3 col-md-6 footer-links">
        <h4>Cabang</h4>
        <ul>
          <li><i class="bx bx-chevron-right"></i> <a href="#"></a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="#">TOWN IPHONE Malang</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="#">TOWN IPHONE Bandung</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="#">TOWN IPHONE Jakarta</a></li>
          <li><i class="bx bx-chevron-right"></i> <a href="#">TOWN IPHONE Pontianak</a></li>
        </ul>
      </div>

      <div class="col-lg-4 col-md-6 footer-newsletter">
        <h4>Join Our Newsletter</h4>
        <p>Tamen quem nulla quae legam multos aute sint culpa legam noster magna</p>
        <form action="" method="post">
          <input type="email" name="email"><input type="submit" value="Subscribe">
        </form>
      </div>

    </div>
  </div>
</div>

<div class="container d-md-flex py-4">

  <div class="me-md-auto text-center text-md-start">
    <div class="copyright">
      &copy; Copyright <strong><span>TOWN IPHONE</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
      <!-- All the links in the footer should remain intact. -->
      <!-- You can delete the links only if you purchased the pro version. -->
      <!-- Licensing information: https://bootstrapmade.com/license/ -->
      <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/medilab-free-medical-bootstrap-theme/ -->
      Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
    </div>
  </div>
  <div class="social-links text-center text-md-right pt-3 pt-md-0">
    <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
    <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
    <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
    <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
    <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
  </div>
</div>
</footer><!-- End Footer -->

<!-- Vendor JS Files -->
<script src="<?= base_url(); ?>/vendor/purecounter/purecounter.js"></script>
<script src="<?= base_url(); ?>/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?= base_url(); ?>/vendor/glightbox/js/glightbox.min.js"></script>
<script src="<?= base_url(); ?>/vendor/swiper/swiper-bundle.min.js"></script>
<script src="<?= base_url(); ?>/vendor/php-email-form/validate.js"></script>

<!-- Template Main JS File -->
<script src="<?= base_url(); ?>/js/main.js"></script>

</body>

</html>